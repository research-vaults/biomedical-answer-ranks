# Anonymous supplementary reproduction package

No paid APIs, GPU or network are needed. Install Python 3 and NumPy.

1. Extract representation_replay.zip. From the extracted directory containing replay.py, run `python3 replay.py`. Expect PASS_ALL_EIGHT.
2. Extract ballot_patterns_replay.zip. Run `python3 analyze.py --base inputs --out outputs`. Compare outputs against expected/.

These commands reconstruct the manuscript's stored-output analyses, not hosted generations or clinical adjudication. The main PDF already includes the textual appendix. The separate source archive rebuilds that PDF with standard TeX Live and latexmk.

3. Extract composition_replay.zip and run `python3 replay.py`. This separately reproduces the exploratory three-partner, four-call analysis; consult its README for exact output comparison.

4. Extract task_strata_replay.zip and run `python3 replay.py --data data --out outputs`. Compare TASK_STRATA.json with expected/. This is a post-review exploratory breakdown of existing Native720 outputs, not a new confirmatory experiment.

5. Extract rank_information_replay.zip and run `python3 replay.py analyze --data data --out outputs`. Compare both JSON files with expected/. This exploratory rank randomization reuses existing native-key ballots; it is not fresh confirmation or quality matching.

6. Extract ballot_diagnostics_v1.zip, read DATA_CARD.md, and run `python3 replay.py --data data --out outputs` followed by `python3 null.py --data data --out outputs`. Compare the three JSON files with expected/. This versioned native-ballot artifact adds exploratory IRV, rank transfer, selection bounds, conditional patterns and risk-coverage analysis; it does not provide new generations or clinical validation.

7. Extract eleven_review_replay.zip and run `python3 replay.py --data data --out outputs`. Compare RESULTS.json, CASE_VECTORS.json and MED_SENSITIVITY.json with expected/. Read the explicit exploratory protocol and restricted interpretation of the information bound, synthetic relabeling and equal-budget screening. No new generations or clinical adjudication.

8. Extract practical_cutoff_replay.zip and run `python3 replay.py --data data --out outputs`. Compare RESULTS.json and CASE_VECTORS.json with expected/. This cutoff/tie challenge reuses five-answer outputs; it is not two-answer generation or published log-probability tie resolution.

9. Extract tie_policy_replay.zip and run `python3 replay.py --data data --source RankBasedSC.py --out outputs`. The archive includes upstream MIT attribution. This is a fixed-output aggregation-component replay and conservative tie-choice sensitivity, not fresh generation or full source-method reproduction.

10. Extract budget_transfer_replay.zip and run `python3 replay.py`. This exploratory eight-call donor-allocation screen retains all four allocations and same-output baselines; it is not fresh confirmation.
