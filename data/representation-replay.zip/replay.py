"""Run five saved-output checks offline; no model calls or network."""
from pathlib import Path
import hashlib, subprocess, sys
base=Path(__file__).resolve().parent
for line in (base/'SHA256SUMS').read_text().splitlines():
    digest,rel=line.split('  ',1)
    assert hashlib.sha256((base/rel).read_bytes()).hexdigest()==digest,rel
for folder,script in [('representation','replay.py'),('competent','replay_competent.py'),('competent','replay_quality_lift.py'),('empirical_reference','replay.py'),('health','replay.py')]:
    subprocess.run([sys.executable,script],cwd=base/folder,check=True)
print('PASS_ALL_FIVE_OFFLINE_REPLAYS')
