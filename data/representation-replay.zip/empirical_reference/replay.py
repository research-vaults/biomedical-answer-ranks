"""Independent Counter/array reconstruction of stored-ballot diagnostics; no model calls."""
import argparse
import hashlib
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path

import numpy as np


def read(p):
    return json.loads(p.read_text())


def rows(p):
    return [json.loads(x) for x in p.read_text().splitlines()]


def exact(listset, gold):
    first = Counter(x[0] for x in listset if x)
    inclusion = Counter(x for ballot in listset for x in ballot)
    def final(c):
        if not c:
            return Fraction(0)
        top = [k for k, v in c.items() if v == max(c.values())]
        return Fraction(int(gold in top), len(top))
    q = Fraction(first[gold], 8)
    wrong = [v for k, v in first.items() if k != gold]
    return [q, Fraction(inclusion[gold] - first[gold], 32),
            Fraction(max(wrong, default=0), 8),
            Fraction(sum(v * (v - 1) for v in wrong), 56),
            q - Fraction(max(wrong, default=0), 8),
            final(first), final(inclusion), final(first) - q]


def simulated(listset, gold):
    """Count all ten labels directly; this does not use the production add.at code."""
    first = np.stack([(listset[:, :, 0] == k).sum(1) for k in range(10)], 1)
    inc = np.stack([(listset == k).sum((1, 2)) for k in range(10)], 1)
    def final(c):
        win = c == c.max(1, keepdims=True)
        return win[:, gold] / win.sum(1) * (c.sum(1) > 0)
    wrong = first.copy()
    wrong[:, gold] = 0
    q = first[:, gold] / 8
    return np.column_stack([q, (inc[:, gold] - first[:, gold]) / 32,
                            wrong.max(1) / 8, (wrong * (wrong - 1)).sum(1) / 56,
                            q - wrong.max(1) / 8, final(first), final(inc), final(first) - q])


def contrast(values, policies, names, metric_names):
    d = {p + '/' + m: values[p][j] for p in policies for j, m in enumerate(metric_names)}
    mix = 'M44' if 'M44' in policies else 'M'
    for h in policies:
        if h == mix:
            continue
        for m in metric_names:
            d[mix + '-' + h + '/' + m] = d[mix + '/' + m] - d[h + '/' + m]
        d['C_vs_' + h] = d[mix + '-' + h + '/F_inclusion'] - d[mix + '-' + h + '/F_first']
    return [float(d[k]) for k in names]


def intervals(values, tasks, seed):
    rng = np.random.default_rng(seed)
    boot = np.zeros((50000, values.shape[1]))
    for task in sorted(set(tasks)):
        ix = np.flatnonzero(tasks == task)
        for start in range(0, 50000, 500):
            selected = rng.choice(ix, (500, len(ix)))
            boot[start:start + 500] += values[selected].sum(1) / len(tasks)
    return np.quantile(boot, [.025, .975], axis=0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--base', type=Path, default=Path(__file__).resolve().parent.parent)
    ap.add_argument('--expected', type=Path, default=Path(__file__).resolve().parent)
    ap.add_argument('--report', type=Path)
    args = ap.parse_args()
    audits = {}
    for n in (288, 720):
        expected = read(args.expected / f'NATIVE_{n}_DIAGNOSTIC_VECTORS.json')
        summary = read(args.expected / f'NATIVE_{n}_DIAGNOSTICS.json')
        if n == 288:
            data = args.base / 'representation/data'
            calls = rows(data / 'native_ballots.jsonl')
            golds = {c['id']: c['label'] for c in read(data / 'design.json')['native_cases']}
            policies = {'H': [('gemma', s) for s in range(8)],
                        'M': [(m, s) for m in ('gemma', 'llama', 'ministral', 'qwen') for s in range(2)]}
            slot, options, offset = 'sample_index', 'option_ids', 0
        else:
            calls = rows(args.base / 'competent/data/competent_calls.jsonl')
            golds = {c['case_id']: c['gold'] for c in calls}
            policies = {'HG': [('gemma', s) for s in range(8)],
                        'HL': [('llama70', s) for s in range(8)],
                        'M44': [(m, s) for m in ('gemma', 'llama70') for s in range(4)]}
            slot, options, offset = 'slot', 'options', 100
        lookup = {(c['case_id'], c['bank'], c['model'], c[slot]): c[options] for c in calls}
        assert len(lookup) == len(calls)
        metrics = [s.split('/', 1)[1] for s in expected['names'][:8]]
        model_slots = {}
        for owned in policies.values():
            for m, s in owned:
                model_slots[m] = max(model_slots.get(m, 0), s + 1)
        rng = np.random.default_rng(20260910231446 + offset)
        observed, reference = [], []
        for cid in expected['ids']:
            gold = golds[cid]
            values = {}
            for p, owned in policies.items():
                banks = [exact([lookup[cid, b, m, s] for m, s in owned], gold) for b in (0, 1)]
                values[p] = [(a + b) / 2 for a, b in zip(*banks)]
            observed.append(contrast(values, policies, expected['names'], metrics))
            pools = {}
            for m in sorted(model_slots):
                lists = [lookup[cid, b, m, s] for b in (0, 1) for s in range(model_slots[m])]
                encoded = np.array([[ord(k) - 65 for k in a] if a else [10] * 5 for a in lists])
                pools[m] = encoded[rng.integers(0, len(lists), (4096, model_slots[m]))]
            v = {p: simulated(np.stack([pools[m][:, s] for m, s in owned], 1), ord(gold)-65).mean(0)
                 for p, owned in policies.items()}
            reference.append(contrast(v, policies, expected['names'], metrics))
        observed, reference = np.array(observed), np.array(reference)
        errors = {'observed': float(np.max(np.abs(observed - expected['observed']))),
                  'reference': float(np.max(np.abs(reference - expected['reference'])))}
        assert errors['observed'] < 1e-12 and errors['reference'] < 1e-12, errors
        # Independently recompute the displayed paired conditional C intervals.
        name = 'C_vs_H' if n == 288 else 'C_vs_HG'
        j = expected['names'].index(name)
        ci = intervals((observed-reference)[:, j:j+1], np.array(expected['tasks']), 20260910231445+offset)[:, 0]
        np.testing.assert_allclose(ci, summary['observed_minus_reference']['ALL'][name]['ci95_conditional_questions'], atol=1e-12)
        audits[str(n)] = {'case_vectors_checked': len(observed), 'metrics_per_case': observed.shape[1],
                          'reference_draws_per_case': 4096, 'max_absolute_errors': errors,
                          'displayed_C_difference': float((observed-reference)[:, j].mean()),
                          'displayed_C_difference_ci95': ci.tolist(),
                          'terminal_empty_slots': sum(not c[options] for c in calls)}
    report = {'status': 'PASS_INDEPENDENT_COUNTER_AND_ARRAY_REPLAY', 'cohorts': audits,
              'new_model_calls': 0, 'interpretation': 'Conditional descriptive reference; no independence/causal test.'}
    if args.report:
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
