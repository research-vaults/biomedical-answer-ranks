# Conditional empirical-list reference

Run `python3 replay.py` in this directory, or the root `python3 replay.py` for all four checks. Requires Python 3 and NumPy; no model calls or network access.

The reference draws complete five-answer lists independently within each question and model, pooling both observed banks, and retains terminal empty lists. Shared draws preserve call sharing across compared policies. There are 4,096 draws per question. The independent implementation uses Counter/Fraction observed votes and direct array label counts for simulated votes. It checks all case vectors, reference means and the two displayed paired C difference intervals (50,000 stratified whole-question resamples).

288-question C: observed 9.7193287037 pp; reference 9.4755465391 pp; difference 0.2437821646 pp, conditional 95% interval [-1.20449036896, 1.71276553724]. 720-question C against Gemma: observed 9.1770833333 pp; reference 8.73195619936 pp; difference 0.44512713397 pp, interval [-0.31557542306, 1.21161757575]. Exact saved vectors and summaries are authoritative for precision.

All diagnostics are post hoc. Conditional intervals omit empirical-list-law estimation uncertainty. Reproducing C under this finite empirical reference is descriptive compatibility, not an independence test, causal attribution or proof that dependence is absent. The stored list pools are small (original non-Gemma models have four lists per question). Cases, not banks, calls or simulation draws, are the sampling unit. Fixed task summaries do not create an outcome-selected policy. No benchmark question text or rationale is included.
