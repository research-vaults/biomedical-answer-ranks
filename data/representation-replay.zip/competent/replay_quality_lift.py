"""Independent offline reconstruction of descriptive quality/lift accounting.

Place beside replay_competent.py and run with Python3 and NumPy. Only stripped
native ballots are read. No network, generation or clinical adjudication occurs.
"""
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path

import numpy as np


def run(base):
    expected = json.loads((base / "data/quality_lift_expected.json").read_text())
    design = json.loads((base / "data/competent_design.json").read_text())
    calls = [json.loads(s) for s in (base / "data/competent_calls.jsonl").read_text().splitlines()]
    by = {(r["case_id"], r["bank"], r["model"], r["slot"]): r for r in calls}
    assert len(calls) == len(by) == 23040
    ids, tasks = expected["case_ids"], expected["tasks"]
    assert len(ids) == len(set(ids)) == 720
    assert sorted(Counter(tasks).values()) == [240, 240, 240]
    observed_ids = {r["case_id"] for r in calls}
    assert observed_ids == set(ids)
    vectors = {key: [] for key in expected["estimates"]}
    for cid in ids:
        values = {}
        for policy, members in [("HG", [("gemma", k) for k in range(8)]), ("HL", [("llama70", k) for k in range(8)]), ("M44", [(m, k) for m in ("gemma", "llama70") for k in range(4)])]:
            qualities, finals = [], []
            for bank in (0, 1):
                bs = [by[cid, bank, m, k] for m, k in members]
                assert len({b["gold"] for b in bs}) == 1
                gold = bs[0]["gold"]
                votes = Counter(b["options"][0] for b in bs if b["options"])
                winners = {k for k in votes if votes[k] == max(votes.values())} if votes else set()
                qualities.append(Fraction(sum(bool(b["options"]) and b["options"][0] == gold for b in bs), 8))
                finals.append(Fraction(int(gold in winners), len(winners)) if winners else Fraction(0))
            values["q_" + policy] = sum(qualities) / 2
            values["F_" + policy] = sum(finals) / 2
            values["L_" + policy] = values["F_" + policy] - values["q_" + policy]
        for h in ("HG", "HL"):
            values["Q_vs_" + h] = values["q_M44"] - values["q_" + h]
            values["deltaL_vs_" + h] = values["L_M44"] - values["L_" + h]
            values["theta_vs_" + h] = values["F_M44"] - values["F_" + h]
            assert values["Q_vs_" + h] + values["deltaL_vs_" + h] == values["theta_vs_" + h]
        for key in vectors:
            vectors[key].append(float(values[key]))
    names = list(vectors)
    values = np.column_stack([vectors[k] for k in names])
    # Use a separate vector reduction, retaining the frozen sample sequence.
    random = np.random.default_rng(expected["seed"])
    draws = expected["draws"]
    bs = np.zeros((draws, len(names)))
    for task in sorted(set(tasks)):
        group = [i for i, t in enumerate(tasks) if t == task]
        samples = random.choice(group, (draws, len(group)))
        for col in range(len(names)):
            bs[:, col] += values[:, col][samples].sum(1) / 720
    estimates = {}
    for j, key in enumerate(names):
        estimates[key] = {"estimate": float(values[:, j].mean()), "ci95": np.quantile(bs[:, j], [.025, .975]).tolist()}
        for field in ("estimate", "ci95"):
            np.testing.assert_allclose(estimates[key][field], expected["estimates"][key][field], rtol=0, atol=1e-12)
    covariance = {}
    for h in ("HG", "HL"):
        keys = ["Q_vs_" + h, "deltaL_vs_" + h, "theta_vs_" + h]
        x = bs[:, [names.index(k) for k in keys]]
        covariance[h] = np.cov(x, rowvar=False, ddof=1).tolist()
        np.testing.assert_allclose(covariance[h], expected["joint_inference"][h]["bootstrap_covariance_probability_squared"], rtol=0, atol=1e-12)
        np.testing.assert_allclose(x[:, 0] + x[:, 1], x[:, 2], rtol=0, atol=1e-12)
    result = {"status": "PASS_RAW_BALLOTS_15_ESTIMATES_30_CI_ENDPOINTS_TWO_JOINT_COVARIANCES", "interpretation": expected["analysis_status"], "cases": 720, "scheduled_calls": 23040, "estimates": estimates, "covariance": covariance}
    (base / "QUALITY_LIFT_REPLAY_RESULTS.json").write_text(json.dumps(result, indent=2) + "\n")
    print(result["status"])


if __name__ == "__main__":
    run(Path(__file__).resolve().parent)
