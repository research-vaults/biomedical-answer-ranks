"""Independent, portable native-ballot replay. No network or provider calls.

Run in an extracted replay package; data/competent_design.json and
data/competent_calls.jsonl contain no questions, rationales or credentials.
Uses exact Fraction scores and argmax sets, independently of study helpers.
"""
from collections import defaultdict
from fractions import Fraction
import json
from pathlib import Path

import numpy as np


def run(base=None):
    base=Path(base) if base else Path(__file__).resolve().parent
    design=json.loads((base/'data/competent_design.json').read_text())
    calls=[json.loads(s) for s in (base/'data/competent_calls.jsonl').read_text().splitlines() if s.strip()]
    by=defaultdict(list)
    unique=set()
    for c in calls:
        key=(c['case_id'],c['bank'],c['model'],c['slot'])
        assert key not in unique;unique.add(key)
        assert len(c['options']) in [0,5]
        assert len(c['options'])==len(set(c['options']))
        by[c['case_id'],c['bank']].append(c)
    ids=sorted(design['tasks']);policies=['HG','HL','M44'];rules=['frequency','first_choice','tie_aware','rr','borda']
    values={p:{r:[] for r in rules} for p in policies};bankvalues={p:{b:{r:[] for r in rules} for b in [0,1]} for p in policies}
    available={p:[] for p in policies};empty={p:0 for p in policies}
    def best(scores):
        if not scores:return set()
        top=max(scores.values());return {k for k,v in scores.items() if v==top}
    for cid in ids:
        for b in [0,1]:
            group=by[cid,b];assert len(group)==16
            assert {c['model'] for c in group}=={'gemma','llama70'}
            for p in policies:
                selected=[c for c in group if (p=='HG' and c['model']=='gemma') or (p=='HL' and c['model']=='llama70') or (p=='M44' and c['slot']<4)]
                assert len(selected)==8
                assert len({c['gold'] for c in selected})==1
                gold=selected[0]['gold'];count=defaultdict(Fraction);top=defaultdict(Fraction);rr=defaultdict(Fraction);borda=defaultdict(Fraction)
                for c in selected:
                    if not c['options']:empty[p]+=1
                    for rank,option in enumerate(c['options'],1):
                        count[option]+=1;rr[option]+=Fraction(1,rank);borda[option]+=6-rank
                        top[option]+=int(rank==1)
                tied=best(count)
                sets={'frequency':tied,'first_choice':best(top),'rr':best(rr),'borda':best(borda),'tie_aware':best({k:rr[k] for k in tied})}
                acc={r:Fraction(int(gold in ws),len(ws)) if ws else Fraction(0) for r,ws in sets.items()}
                assert all(v<=int(gold in count) for v in acc.values())
                for r in rules:bankvalues[p][b][r].append(float(acc[r]))
                available[p].append(int(gold in count))
        for p in policies:
            for r in rules:values[p][r].append((bankvalues[p][0][r][-1]+bankvalues[p][1][r][-1])/2)
    assert len(calls)==len(ids)*32==23040
    rng=np.random.default_rng(design['bootstrap_seed'])
    groups=[[i for i,c in enumerate(ids) if design['tasks'][c]==t] for t in sorted(set(design['tasks'].values()))]
    samples=np.concatenate([rng.choice(g,(design['bootstrap_draws'],len(g))) for g in groups],axis=1)
    def est(v):
        v=np.array(v);means=np.concatenate([v[s].mean(1) for s in np.array_split(samples,20)])
        return dict(estimate=float(v.mean()),ci95=np.quantile(means,[.025,.975]).tolist())
    vec={p:{r:np.array(v) for r,v in rs.items()} for p,rs in values.items()}
    out=dict(primary=est(vec['M44']['first_choice']-vec['HG']['first_choice']),
             absolute={p:{r:est(v) for r,v in rs.items()} for p,rs in vec.items()},
             allocation_C={p:est((vec['M44']['frequency']-vec[p]['frequency'])-(vec['M44']['first_choice']-vec[p]['first_choice'])) for p in ['HG','HL']},
             bank_primary={str(b):est(np.array(bankvalues['M44'][b]['first_choice'])-np.array(bankvalues['HG'][b]['first_choice'])) for b in [0,1]},
             available={p:float(np.mean(v)) for p,v in available.items()},failed_slots=empty,n_cases=len(ids),n_unique_calls=len(calls))
    expected=design['expected']
    def close(actual,ref,path=''):
        if isinstance(ref,dict):
            for k,v in ref.items():close(actual[k],v,path+'/'+k)
        elif isinstance(ref,list):
            assert np.allclose(actual,ref,atol=1e-12,rtol=0),path
        elif isinstance(ref,(int,float)):
            assert abs(actual-ref)<1e-12,(path,actual,ref)
        else:assert actual==ref,path
    close(out,expected)
    out['status']='PASS_INDEPENDENT_EXACT_BALLOT_AND_CASE_BOOTSTRAP_REPLAY'
    (base/'COMPETENT_REPLAY_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:out[k] for k in ['status','primary','allocation_C','n_cases','n_unique_calls']},indent=2))
    return out


if __name__=='__main__':run()
