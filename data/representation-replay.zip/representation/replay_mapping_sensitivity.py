"""Offline mapping-policy and complete-case sensitivity; never recodes primary data."""
from pathlib import Path
from fractions import Fraction
from collections import defaultdict, Counter
import hashlib, json
import numpy as np

def run():
    root = Path(__file__).resolve().parent
    def read(name): return json.loads((root/'data'/name).read_text())
    def rows(name): return [json.loads(s) for s in (root/'data'/name).read_text().splitlines()]
    for line in (root/'SHA256SUMS').read_text().splitlines():
        digest, rel = line.split('  ', 1)
        assert hashlib.sha256((root/rel).read_bytes()).hexdigest() == digest, rel
    spec = read('mapping_sensitivity.json')
    ids = spec['case_ids']; rr = rows('mapping_relation_coefficients.jsonl')
    assert len(rr) == 3607 and len(ids) == 96
    assert sum(r['new'] and r['unresolved'] and r['refinement'] for r in rr) == 10
    vectors = {s: defaultdict(Fraction) for s in spec['expected']}
    for row in rr:
        values = {'implemented_frozen_refinement': row['refinement'],
                  'new_unresolved_zero_credit': 0 if row['new'] and row['unresolved'] else row['refinement'],
                  'all_strict_unresolved_zero_credit': 0 if row['unresolved'] else row['refinement']}
        for scenario, value in values.items():
            for cid, coef in row['case_C_coefficients'].items():
                vectors[scenario][cid] += Fraction(coef) * value
    boot = np.random.default_rng(spec['bootstrap_seed']).integers(0, len(ids), (spec['bootstrap_draws'], len(ids)))
    mapping = {}
    for scenario, vec in vectors.items():
        arr = np.array([float(vec[c]) for c in ids]); ci = np.quantile(arr[boot].mean(1), [.025,.975])
        out = {'estimate': float(arr.mean()), 'ci95': ci.tolist(), 'n_cases': len(ids)}
        expected = spec['expected'][scenario]
        assert abs(out['estimate'] - expected['estimate']) < 1e-12
        assert np.max(np.abs(ci - expected['ci95'])) < 1e-12
        mapping[scenario] = out
    # This is a selected population, so the declared sensitivity is unstratified.
    cc = read('complete_case_sensitivity.json'); complete = {}
    for source, inputs in cc['sources'].items():
        kept = [c for c in inputs if c['complete']]
        vec = np.array([c['C'] for c in kept]); n = len(kept)
        draws = np.random.default_rng(cc['seed']).integers(0,n,(cc['draws'],n))
        out = {'kept_cases': n, 'excluded_cases': len(inputs)-n, 'C': float(vec.mean()),
               'ci95_whole_case': np.quantile(vec[draws].mean(1),[.025,.975]).tolist(),
               'task_counts': dict(Counter(c.get('task','paired clinical case') for c in kept))}
        exp = cc['expected'][source]
        assert n == exp['kept_cases'] and abs(out['C'] - exp['C']) < 1e-12
        assert np.max(np.abs(np.array(out['ci95_whole_case'])-exp['ci95_whole_case'])) < 1e-12
        complete[source] = out
    output = {'status': 'PASS_MAPPING_AND_COMPLETE_CASE_SENSITIVITY', 'mapping': mapping, 'complete_case': complete,
              'limitations': 'Mapping flags and exact signed case coefficients are exported from the frozen relation audit; this checks their arithmetic, not clinical correctness. Complete-case selection is post-outcome and does not replace the primary population.'}
    (root/'SENSITIVITY_REPLAY_RESULTS.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2))
    return output

if __name__ == '__main__': run()
