"""Offline, text-free replay of the fresh representation study and fixed predictor.
Run beside the exported data/ directory: python3 replay.py
Requires Python3 and NumPy. No network or provider code is included.
"""
from pathlib import Path
from fractions import Fraction
from collections import defaultdict,Counter
import csv,hashlib,json
import numpy as np
ROOT=Path(__file__).resolve().parent
D=ROOT/'data'
def read(n):return json.loads((D/n).read_text())
def readl(n):return [json.loads(x) for x in (D/n).read_text().splitlines() if x.strip()]
def write(n,x):(ROOT/n).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
for line in (ROOT/'SHA256SUMS').read_text().splitlines():
 digest,rel=line.split('  ',1);assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest,rel
cfg=read('design.json');expected=read('expected.json');native={x['id']:x for x in cfg['native_cases']}
def wins(ranks,depth=5):
 if not ranks:return {k:[] for k in ['frequency','first_choice','rr','borda','tie_aware']}
 f=[sum(r<=depth for r in rs) for rs in ranks];top=[rs.count(1) for rs in ranks]
 rr=[sum((Fraction(1,r) for r in rs if r<=depth),Fraction()) for rs in ranks]
 borda=[sum(6-r for r in rs) for rs in ranks]
 def best(v,allowed=None):
  ids=list(range(len(v))) if allowed is None else allowed
  return [i for i in ids if v[i]==max(v[j] for j in ids)] if ids else []
 tie=best(f)
 return {'frequency':tie,'first_choice':best(top),'rr':best(rr),'borda':best(borda),'tie_aware':best(rr,tie)}
def score(w,y):return float(Fraction(sum(y[i] for i in w),len(w))) if w else 0.
def features(ranks):
 return np.array([len(ranks)/10,max((rs.count(1) for rs in ranks),default=0)/8,float(len(wins(ranks)['frequency'])>1)])
# Primary pools are independently reconstructed from stripped native output ballots.
ballots=readl('native_ballots.jsonl');assert len(ballots)==8064
by=defaultdict(list)
for b in ballots:by[b['case_id'],b['bank']].append(b)
pools=[]
for (cid,bank),calls in sorted(by.items()):
 assert len(calls)==14
 for a in ['H','M']:
  chosen=[b for b in calls if (b['model']=='gemma' if a=='H' else b['sample_index']<2)]
  assert len(chosen)==8
  ranks=defaultdict(list)
  for b in chosen:
   assert len(b['option_ids']) in [0,5] and len(b['option_ids'])==len(set(b['option_ids']))
   for r,key in enumerate(b['option_ids'],1):ranks[key].append(r)
  keys=sorted(ranks)
  pools.append(dict(source='native',case_id=cid,bank=bank,branch='native',allocation=a,ranks=[ranks[k] for k in keys],criteria={'native_key':[int(k==native[cid]['label']) for k in keys]}))
pools+=readl('med_scored_rank_pools.jsonl')
rows=[]
for p in pools:
 for criterion,y in p['criteria'].items():
  ws=wins(p['ranks']);row={k:p[k] for k in ['source','case_id','bank','branch','allocation']}
  row.update(criterion=criterion,scores={m:score(w,y) for m,w in ws.items()},depth={str(d):{m:score(w,y) for m,w in wins(p['ranks'],d).items()} for d in range(1,6)})
  assert all(v<=int(any(y)) for v in row['scores'].values())
  rows.append(row)
results={};curves=[]
for source,criteria in [('native',['native_key']),('medeinst',['refinement','strict','exact_reference'])]:
 ids=sorted({p['case_id'] for p in pools if p['source']==source});rng=np.random.default_rng(202609091733)
 if source=='native':
  groups=[[i for i,c in enumerate(ids) if native[c]['task']==t] for t in sorted({c['task'] for c in native.values()})]
  boot=np.concatenate([rng.choice(g,(50000,len(g))) for g in groups],axis=1)
 else:boot=rng.integers(0,len(ids),(50000,len(ids)))
 def stat(v):
  v=np.array(v);return {'estimate':float(v.mean()),'ci95':np.quantile(v[boot].mean(1),[.025,.975]).tolist()}
 for criterion in criteria:
  cells=defaultdict(list)
  for row in rows:
   if (row['source'],row['criterion'])==(source,criterion):cells[row['case_id'],row['allocation']].append(row)
  def arr(a,get):return np.array([np.mean([get(row) for row in cells[c,a]]) for c in ids])
  cv=arr('M',lambda row:row['scores']['frequency']-row['scores']['first_choice'])-arr('H',lambda row:row['scores']['frequency']-row['scores']['first_choice'])
  out={'C':stat(cv),'absolute':{},'allocation':{}}
  for m in ['frequency','first_choice','rr','borda','tie_aware']:
   out['absolute'][m]={a:float(arr(a,lambda row:row['scores'][m]).mean()) for a in ['H','M']}
   out['allocation'][m]=stat(arr('M',lambda row:row['scores'][m])-arr('H',lambda row:row['scores'][m]))
  for d in range(1,6):
   for m in ['frequency','rr','tie_aware']:
    v=arr('M',lambda row:row['depth'][str(d)][m])-arr('H',lambda row:row['depth'][str(d)][m])
    z=stat(v);curves.append(dict(source=source,criterion=criterion,depth=d,rule=m,estimate=z['estimate'],lower95=z['ci95'][0],upper95=z['ci95'][1]))
  key=source+'|'+criterion;results[key]=out;e=expected['C'][key]
  assert abs(out['C']['estimate']-e['estimate'])<1e-12
  assert np.max(np.abs(np.array(out['C']['ci95'])-e['ci95']))<1e-12
  if source=='native':
   assert ids==expected['native_vectors']['case_ids'] and np.max(np.abs(cv-expected['native_vectors']['C']))<1e-12
   for m,z in out['absolute'].items():
    for a,v in z.items():assert abs(v-expected['native_absolute'][m][a])<1e-12
# Refit the frozen old-native training recipe; no new held-out model selection.
def design(data):
 by={}
 for p in data:
  if p.get('source','native')!='native':continue
  y=p['criteria']['native_key'];w=wins(p['ranks'])
  by[p['case_id'],p.get('bank',0),p['allocation']]=(features(p['ranks']),score(w['frequency'],y)-score(w['first_choice'],y))
 ids=sorted({x[0] for x in by});xs=[];ys=[]
 for cid in ids:
  xx=[];yy=[]
  for bank in sorted({x[1] for x in by if x[0]==cid}):
   h,hc=by[cid,bank,'H'];m,mc=by[cid,bank,'M'];xx.append([m[0]-h[0],m[1]-h[1],h[2]-m[2]]);yy.append(mc-hc)
  xs.append(np.mean(xx,axis=0));ys.append(np.mean(yy))
 return ids,np.array(xs),np.array(ys)
old_ids,tx,ty=design(readl('old_native_training_rank_pools.jsonl'));ids,x,y=design(pools)
assert len(old_ids)==128 and len(ids)==288 and not set(old_ids)&set(ids)
spec=read('frozen_predictor.json');pred={'constant':np.repeat(spec['constant'],len(y))}
for name,k in [('quality_count',2),('plus_tie_gap',3)]:
 mean=tx[:,:k].mean(0);scale=tx[:,:k].std(0);scale[scale==0]=1;z=(tx[:,:k]-mean)/scale
 coef=np.linalg.solve(z.T@z+np.eye(k),z.T@(ty-ty.mean()));m=spec['models'][name]
 assert np.allclose(coef,m['coefficient'],atol=1e-12,rtol=0)
 pred[name]=(x[:,:k]-mean)/scale@coef+ty.mean()
loss={k:(v-y)**2 for k,v in pred.items()};delta=loss['quality_count']-loss['plus_tie_gap']
rng=np.random.default_rng(202609091821);groups=[[i for i,c in enumerate(ids) if native[c]['task']==t] for t in sorted({c['task'] for c in native.values()})]
boot=np.concatenate([rng.choice(g,(50000,len(g))) for g in groups],axis=1)
predictor={'mse':{k:float(v.mean()) for k,v in loss.items()},'paired_mse_reduction':{'estimate':float(delta.mean()),'ci95':np.quantile(delta[boot].mean(1),[.025,.975]).tolist()}}
e=expected['predictor']
assert abs(predictor['paired_mse_reduction']['estimate']-e['paired_mse_reduction']['estimate'])<1e-12
assert np.max(np.abs(np.array(predictor['paired_mse_reduction']['ci95'])-e['paired_mse_reduction']['ci95']))<1e-12
write('REPLAY_RESULTS.json',{'status':'PASS_FRESH_STUDY_AND_FIXED_PREDICTOR_REPLAY','results':results,'predictor':predictor,'native_slots':len(ballots),'native_failed_slots':sum(not b['option_ids'] for b in ballots),'med_authority':'Exported frozen criterion labels; not independent clinical adjudication or terminology-map regeneration','scope':'Fresh representation study and predictor only; not full historical experiment or live-serving reproduction'})
with (ROOT/'ALLOCATION_CURVES.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(curves[0]));w.writeheader();w.writerows(curves)
print(json.dumps({'status':'PASS','C':{k:v['C'] for k,v in results.items()},'predictor':predictor},indent=2))

import replay_mapping_sensitivity
replay_mapping_sensitivity.run()
