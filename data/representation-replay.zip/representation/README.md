# Offline representation-study replay supplement

artifact_status: INTERNAL_DRAFT; prepared locally, not publicly released or submitted.

Run `python3 replay.py` from this extracted directory with Python3 and NumPy installed. It verifies SHA256SUMS and writes REPLAY_RESULTS.json plus ALLOCATION_CURVES.csv. It makes no model calls, network requests or credential reads. The cold verification used the local NumPy version recorded in PROVENANCE.json. The native primary, all fresh C criteria, ten native absolute rule/allocation cells, depth curves, and the fixed old-native-trained predictor are independently recomputed; stored expected values are used only as final regression checks.

Data contain native case IDs, task strata, answer-key letters and stripped ranked option-ID outputs for all8064 native generation slots, with failures empty. MedEinst exports candidate-rank multisets and fixed scoring flags per candidate, without narrative text or diagnosis surfaces. Old128 native rank pools support refitting the fixed ridge predictor. Question text, option text, rationales, patient narratives, raw provider payloads, account IDs and credentials are excluded. No new data license or rights attestation is implied by this internal export.

The 288 native questions and96 MedEinst pairs are distinct populations; banks/branches are averaged within case. Each source uses the frozen50000-draw whole-case bootstrap; native preserves task strata. The prediction check was frozen after new generation began but before fresh accuracy analysis. It has no resolved incremental MSE benefit. The predictor is not tuned during replay.

This package reproduces saved-data inference for the new representation study and predictor. It does not regenerate model outputs, independently establish provider randomness, reconstruct clinical terminology mappings or reproduce every historical study in the paper. MedEinst correctness flags inherit the frozen deterministic mapping/criterion limitations. Benchmark keys do not establish clinical truth. The full source-paper archive and local project retain historical protocols and broader analyses.


## September 10 audit update

The same command now also writes SENSITIVITY_REPLAY_RESULTS.json. It recomputes MedEinst mapping-policy contrasts from 3,607 stripped relation records and exact signed per-case coefficients, including the discrepancy between frozen prose (newly unresolved relations receive no credit) and the implemented refinement whitelist (10 newly unresolved types receive credit). Both the original implemented estimate and the conservative prose-consistent sensitivity are preserved. The original estimate is not silently replaced. Flags and coefficients inherit the source audit; this is not independent clinical adjudication and cannot establish correctness of unresolved relations.

The package also replays the explicitly seeded, 50,000-draw unstratified whole-case sensitivity for 193 complete native cases and 88 complete MedEinst pairs. The source audit verifies their membership against terminal failures. These subsets are selected after generation, have a different task composition, and do not replace the frozen primary population. Stored case contrasts are the independently verified inference inputs; this sensitivity checks their selection and interval arithmetic. The primary script independently reconstructs the native contrasts from ranked ballots before these checks.
