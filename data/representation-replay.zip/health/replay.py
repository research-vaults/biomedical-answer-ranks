"""Offline exact-rational replay of the prespecified Health source transport."""
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
import hashlib, json
import numpy as np

root=Path(__file__).resolve().parent
meta=json.loads((root/'metadata.json').read_text())
for name,digest in meta['data_hashes'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
pools=[json.loads(x) for x in (root/'pools.jsonl').read_text().splitlines()]
expected=json.loads((root/'expected.json').read_text())
sums=defaultdict(lambda:defaultdict(Fraction));ids=sorted({p['case_id'] for p in pools})
assert len(ids)==meta['n_cases'] and len(pools)==len(ids)*6
for p in pools:
    r=p['ranks'];y=p['correct'];assert len(r)==len(y)
    scores={'frequency':[Fraction(len(a)) for a in r],
            'first_choice':[Fraction(a.count(1)) for a in r],
            'rr':[sum((Fraction(1,j) for j in a),Fraction()) for a in r],
            'borda':[Fraction(sum(6-j for j in a)) for a in r]}
    best=max(scores['frequency'],default=0)
    scores['tie_aware']=[scores['rr'][i] if x==best else Fraction(-1) for i,x in enumerate(scores['frequency'])]
    for rule,vs in scores.items():
        wins=[i for i,v in enumerate(vs) if v==max(vs)] if vs else []
        value=Fraction(sum(y[i] for i in wins),len(wins)) if wins else Fraction()
        sums[p['case_id'],p['policy']][rule]+=value/Fraction(meta['banks'])
vectors={p:{r:np.array([float(sums[c,p][r]) for c in ids]) for r in scores} for p in ['HG','HL','M44']}
C=vectors['M44']['frequency']-vectors['HG']['frequency']-vectors['M44']['first_choice']+vectors['HG']['first_choice']
theta=vectors['M44']['first_choice']-vectors['HG']['first_choice']
rng=np.random.default_rng(meta['bootstrap_seed']);draws=rng.choice(list(range(len(ids))),(meta['bootstrap_draws'],len(ids)))
def est(x):return {'estimate':float(x.mean()),'ci95':np.quantile(x[draws].mean(1),[.025,.975]).tolist()}
def check(a,b):
    assert abs(a['estimate']-b['estimate'])<1e-12
    assert np.max(abs(np.array(a['ci95'])-b['ci95']))<1e-12
check(est(C),expected['primary']);check(est(theta),expected['theta_secondary'])
for p,rs in vectors.items():
    for r,x in rs.items():check(est(x),expected['absolute'][p][r])
output={'status':'PASS_HEALTH_PRIMARY_SECONDARY_AND_15_RULE_CELLS','n_cases':len(ids),'primary_C':est(C),'secondary_theta':est(theta),'scope':'Fixed educational Health subset; stored-output inference only, no clinical adjudication or new model calls'}
(root/'REPLAY_RESULT.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output,indent=2))
