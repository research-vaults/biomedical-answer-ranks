# Anonymous stored-output inference replay

Extract and run `python3 replay.py` with Python3 and NumPy. No credentials or network are required. The command runs both analyses and stops on any mismatch.

`representation/` preserves the original replay, negative predictor, mapping-policy discrepancy and complete-case sensitivities. Its own README explains the inherited mapping authority and numerical checks.

`competent/` independently reconstructs all five rule accuracies for Gemma8, Llama3.3-70B8 and their4+4 mixture from23,040 stripped per-call native-option lists. Exact rational vote weights and winner sets are independent of the collection analyzer. It replays the primary estimate and50,000-draw task-stratified case-bootstrap interval, C against both homogeneous families, bank-specific primary intervals, availability and retained failures. The720 new questions average two banks within case. The frozen primary is mixed-minus-Gemma first-choice accuracy, selected on development before these outputs; the practical margin is+5 percentage points. Other intervals are pointwise secondary.

This is a second experiment on the same native source with a two-model mixture. It is not another bank of the original four-model primary and is not independent-source or clinical validation. The second family passed a development competence screen; this does not prove quality equivalence. One incomplete earlier confirmation was retired after a disk-write failure before outcome analysis; all720 assigned questions were excluded from this replacement. Incomplete calls are neither pooled into these outcomes nor represented as zero cost. Their raw records and conservative cost reserve remain in the internal execution audit.

The stripped replay includes no questions, rationales, API credentials, local absolute paths or provider access. It checks inference on stored ballots; it does not regenerate outputs, independently establish benchmark-key correctness, or replay every historical selector experiment. Protocol/configuration fingerprints and numeric expectations bind the included inputs. Local packaging does not constitute public release or submission.

The third check, `competent/replay_quality_lift.py`, independently reconstructs per-call quality and first-choice final accuracy with exact rational votes from the same stripped calls. It verifies all 15 descriptive estimates, their 30 interval endpoints and both joint covariance matrices. Whole cases retain both banks and shared policy calls; terminal failures stay in the eight-call denominator. This is post-hoc descriptive accounting with pointwise 95% component intervals, not a new confirmatory test or an identification of causal diversity shares. Its primary sum reproduces the frozen final-decision interval. No additional generation, independent dataset or clinical authority is added.

A fourth check in `empirical_reference/` reconstructs the post-hoc independent-list reference and conditional intervals on the same 288/720 cases. It does not test independence or identify causality.

Archive repair, 11 September 2026: all 35 files include both required checksum manifests. The root runner verifies the complete extraction before the four existing offline checks. No experimental data or inference method changed.

## Health-source extension (11 September 2026)
Run `python3 replay.py` after installing NumPy. A fifth check independently reconstructs exact rational votes, 15 absolute rule cells and paired 50,000-draw C/theta intervals for 256 new MMLU-Pro Health questions and two banks. `health/metadata.json` supplies pinned public source retrieval and hashes; `health/pools.jsonl` contains identifiers and scored ranks, not question text. The four previous checks and inputs are preserved. This verifies inference on saved outputs, not fresh hosted generation or clinical correctness.
